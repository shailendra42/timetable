package sta.uwi.edu.uwi_statimetablecompanion;

public class Class
{
    private Venue venue;
    private String course;
    //private SomeType timePeriod;

    public Class(String course, Venue venue)
    {
        this.course = course;
        this.venue = venue;
    }
}
