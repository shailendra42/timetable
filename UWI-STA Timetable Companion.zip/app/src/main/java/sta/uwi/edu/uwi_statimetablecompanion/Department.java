package sta.uwi.edu.uwi_statimetablecompanion;

public class Department {
}
