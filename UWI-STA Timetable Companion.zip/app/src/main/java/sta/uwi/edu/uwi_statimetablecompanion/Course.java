package sta.uwi.edu.uwi_statimetablecompanion;

import java.util.ArrayList;

public class Course
{
    private String name;
    private String dept;
    private String code;
    private boolean selected;
    private ArrayList<Class> classes;

    public Course(String dept,String code, String name)
    {
        this.dept = dept;
        this.name = name;
        this.code = code;
        selected = false;
        addClasses();
    }

    private void addClasses()
    {
        // read from file or database, create and add course classes to arraylist
    }

    public void setSelected(boolean b)
    {
        selected = b;
    }
    public boolean getSelected()
    {
        return selected;
    }
    public String getDept(){return dept;}
    public String getCourseCode(){return code;}
    @Override
    public String toString() {
        return this.code +" ("+ this.name+")";
    }
}
